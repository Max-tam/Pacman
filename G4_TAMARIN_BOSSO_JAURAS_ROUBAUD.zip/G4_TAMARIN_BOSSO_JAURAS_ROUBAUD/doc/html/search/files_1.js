var searchData=
[
  ['bgtext_2ecpp_426',['bgtext.cpp',['../08-_custom_drawable_2bgtext_8cpp.html',1,'(Global Namespace)'],['../09-_custom_transitionable_2bgtext_8cpp.html',1,'(Global Namespace)']]],
  ['bgtext_2eh_427',['bgtext.h',['../08-_custom_drawable_2bgtext_8h.html',1,'(Global Namespace)'],['../09-_custom_transitionable_2bgtext_8h.html',1,'(Global Namespace)']]]
];
