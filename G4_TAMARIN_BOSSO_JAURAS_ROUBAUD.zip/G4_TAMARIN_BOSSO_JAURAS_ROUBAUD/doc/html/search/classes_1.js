var searchData=
[
  ['bgtext_388',['BgText',['../class_bg_text.html',1,'']]]
];
