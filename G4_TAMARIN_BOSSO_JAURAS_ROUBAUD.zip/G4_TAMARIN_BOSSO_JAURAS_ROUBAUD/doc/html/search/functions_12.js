var searchData=
[
  ['vec2d_637',['Vec2D',['../classns_graphics_1_1_vec2_d.html#a4a2fdd532ded3c29b7a3bd6e5a23fadf',1,'nsGraphics::Vec2D::Vec2D(const int &amp;x=0, const int &amp;y=0)'],['../classns_graphics_1_1_vec2_d.html#ae409c698404abced934b589d58513767',1,'nsGraphics::Vec2D::Vec2D(const Vec2D &amp;pos)']]],
  ['verificationcollision_638',['verificationCollision',['../main_8cpp.html#ae5e2ce8311c0acae4689618b3700317c',1,'main.cpp']]]
];
