var searchData=
[
  ['datamagic_655',['datamagic',['../sprite_8h.html#a43e5468a3d445613419004493d2ffac8',1,'sprite.h']]],
  ['direction_656',['direction',['../structfantome.html#a7960afdec648bc08931bad0ed9aa182f',1,'fantome']]]
];
